// Daily colour contrast check for MarketPulse. Usage: node contrast.js <site.html>
// Checks every visible text element on every page, in light and dark mode, against WCAG AA (4.5:1, or 3:1 for large text).
const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const res={};let total=0;
for(const theme of ['light','dark']){
 const p=await b.newPage({viewport:{width:1100,height:900},colorScheme:theme});
 await p.goto(process.argv[2]);await p.waitForSelector('#boot',{state:'detached',timeout:20000});await p.evaluate(()=>{window.__noGate=true});
 await p.evaluate(t=>{try{SET.theme=t;saveSet();applySet()}catch(e){document.documentElement.dataset.theme=t}},theme);
 const pages=await p.evaluate(()=>PAGES.slice());
 for(const pg of pages){
  await p.evaluate(x=>{try{if(x==='stock'&&!curStock)curStock=S[0].id;show(x)}catch(e){}},pg);await p.waitForTimeout(120);
  const bad=await p.evaluate(()=>{
   const parse=c=>{const m=c.match(/rgba?\(([^)]+)\)/);if(!m)return null;const a=m[1].split(/[ ,\/]+/).map(Number);return{r:a[0],g:a[1],b:a[2],a:a[3]===undefined?1:a[3]}};
   const lum=c=>{const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(c.r)+.7152*f(c.g)+.0722*f(c.b)};
   const bgOf=e=>{let layers=[];for(let n=e;n;n=n.parentElement){const c=parse(getComputedStyle(n).backgroundColor);if(c&&c.a>0){layers.push(c);if(c.a>=1)break}}
     let base={r:255,g:255,b:255,a:1};if(!layers.length||layers[layers.length-1].a<1){const bc=parse(getComputedStyle(document.body).backgroundColor);if(bc&&bc.a>0)base=bc}
     for(let i=layers.length-1;i>=0;i--){const l=layers[i];base={r:l.r*l.a+base.r*(1-l.a),g:l.g*l.a+base.g*(1-l.a),b:l.b*l.a+base.b*(1-l.a),a:1}}return base};
   const out=[];const seen=new Set();
   document.querySelectorAll('body *').forEach(e=>{
    if(!e.offsetParent&&getComputedStyle(e).position!=='fixed')return;
    const own=[...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim());if(!own)return;
    const cs=getComputedStyle(e);if(cs.visibility==='hidden'||+cs.opacity===0)return;
    const fg=parse(cs.color);if(!fg)return;const bg=bgOf(e);
    const fa=fg.a;const f2={r:fg.r*fa+bg.r*(1-fa),g:fg.g*fa+bg.g*(1-fa),b:fg.b*fa+bg.b*(1-fa)};
    const L1=lum(f2),L2=lum(bg);const ratio=(Math.max(L1,L2)+.05)/(Math.min(L1,L2)+.05);
    const px=parseFloat(cs.fontSize),bold=+cs.fontWeight>=700;const large=px>=24||(px>=18.66&&bold);
    const need=large?3:4.5;
    if(ratio<need){const k=(e.className||e.tagName)+'|'+cs.color+'|'+JSON.stringify(bg);if(seen.has(k))return;seen.add(k);out.push({el:(e.id?'#'+e.id:'')+'.'+String(e.className).split(' ')[0]||e.tagName,text:e.innerText.trim().slice(0,30),ratio:+ratio.toFixed(2),need})}
   });return out;});
  total+=bad.length;if(bad.length)res[theme+' / '+pg]=bad;
 }
 await p.close();
}
console.log(JSON.stringify({failures:total,detail:res},null,1));
await b.close();process.exit(total?1:0);})();
