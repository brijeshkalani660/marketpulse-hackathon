// MarketPulse cache: pages and data you have already loaded open instantly on repeat visits.
// Stale-while-revalidate: you see the saved copy at once, and a fresh copy is fetched in the background for next time.
// Prices live in data/prices.gz.txt and are fetched network-first, so a daily update shows on the next visit; if offline it falls back to the saved copy.
const V = "mp-v2";
self.addEventListener("install", e => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener("fetch", e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.origin !== location.origin) return;
  if (/\/data\/prices\.gz\.txt$/.test(u.pathname)) { e.respondWith(caches.open(V).then(async c => { try { const res = await fetch(r); if (res && res.ok) c.put(r, res.clone()); return res; } catch (x) { const hit = await c.match(r); if (hit) return hit; throw x; } })); return; }
  e.respondWith(caches.open(V).then(async c => {
    const hit = await c.match(r);
    const net = fetch(r).then(res => { if (res && res.ok) c.put(r, res.clone()); return res; }).catch(() => hit);
    return hit || net;
  }));
});
