// MarketPulse performance budget. Usage: node perf_budget.js <folder with index.html and data/>   Exit code 0 = PASS, 1 = FAIL.
const fs = require("fs"), path = require("path"), http = require("http"), zlib = require("zlib"), crypto = require("crypto");
const { chromium } = require("playwright");
const DIR = path.resolve(process.argv[2] || "."), B = {            // ---- the budget (edit here) ----
  indexKB: 300, dataFileKB: 150, firstLoadKB: 520, langFileKB: 8, siteKB: 900, lazyHistKB: 9000, lazyDailyKB: 3000, lazyKB: 12000,
  readyMs: 2500, readySlowMs: 8000, domNodes: 4000, listMs: 10000, listRows: 3000, langMs: 2000, jsErrors: 0 };
const rows = []; const chk = (name, val, limit, unit, ok) => rows.push({ name, val, limit, unit, ok: ok === undefined ? val <= limit : ok });
const size = f => fs.statSync(path.join(DIR, f)).size, kb = n => Math.round(n / 102.4) / 10;
const all = (d => { const o = []; (function w(x) { for (const f of fs.readdirSync(x)) { const p = path.join(x, f); fs.statSync(p).isDirectory() ? w(p) : o.push(path.relative(DIR, p)); } })(d); return o; })(DIR);
(async () => {
  // 1. file sizes
  chk("index.html size", kb(size("index.html")), B.indexKB, "KB");
  const data = all.filter(f => f.startsWith("data/") && f.endsWith(".gz.txt"));
  const LAZY = ["data/history.gz.txt", "data/daily.gz.txt"];  // loaded only when a stock page opens, so budgeted on their own
  const big = data.filter(f => !f.includes("lang-") && !LAZY.includes(f)).map(f => [f, kb(size(f))]).sort((a, b) => b[1] - a[1])[0];
  chk("largest data file (" + big[0] + ")", big[1], B.dataFileKB, "KB");
  chk("largest language file", Math.max(...data.filter(f => f.includes("lang-")).map(f => kb(size(f)))), B.langFileKB, "KB");
  chk("first-visit download", kb(["index.html", "data/catalogue.gz.txt", "data/prices.gz.txt", "data/learn.gz.txt", "data/estimates.gz.txt", "sw.js"].reduce((a, f) => a + size(f), 0)), B.firstLoadKB, "KB");
  chk("history file (loaded only on a stock page)", kb(size("data/history.gz.txt")), B.lazyHistKB, "KB");
  chk("daily file (loaded only on a stock page)", kb(size("data/daily.gz.txt")), B.lazyDailyKB, "KB");
  chk("whole site without the two stock-page files", kb(all.filter(f => !LAZY.includes(f)).reduce((a, f) => a + size(f), 0)), B.siteKB, "KB");
  // 2. lossless / retrievable
  const man = JSON.parse(fs.readFileSync(path.join(DIR, "data/manifest.json"))).files; let bad = [];
  for (const [n, m] of Object.entries(man)) {
    try { const raw = zlib.gunzipSync(Buffer.from(fs.readFileSync(path.join(DIR, m.file), "utf8").trim(), "base64")); JSON.parse(raw); if (crypto.createHash("sha256").update(raw).digest("hex") !== m.sha256_of_json) bad.push(n); } catch (e) { bad.push(n); }
  }
  chk("data files decode and match their checksum", bad.length, 0, bad.length ? bad.join(",") : "bad files");
  const langs = Object.keys(man).filter(n => n.startsWith("lang-"));
  chk("languages available (incl. English)", langs.length + 1, 50, "", langs.length + 1 >= 50);
  // 3. browser checks
  const srv = http.createServer((q, r) => { let p = path.join(DIR, decodeURIComponent(q.url.split("?")[0])); if (p.endsWith("/")) p += "index.html"; fs.readFile(p, (e, d) => { if (e) { r.statusCode = 404; return r.end(); } r.setHeader("content-type", /\.html$/.test(p) ? "text/html" : /\.js$/.test(p) ? "text/javascript" : /\.png$/.test(p) ? "image/png" : "text/plain"); r.end(d); }); }).listen(0);
  const url = "http://localhost:" + srv.address().port + "/index.html";
  const br = await chromium.launch({ executablePath: process.env.CHROMIUM || undefined });
  const errs = [];
  const open = async (slow) => {
    const ctx = await br.newContext({ viewport: { width: 360, height: 740 } }), p = await ctx.newPage();
    p.on("pageerror", e => errs.push(e.message)); p.on("console", m => { if (m.type() === "error" && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });
    if (slow) { const c = await ctx.newCDPSession(p); await c.send("Network.emulateNetworkConditions", { offline: false, latency: 150, downloadThroughput: 200000, uploadThroughput: 100000 }); }
    await p.route(/^https?:\/\/(?!localhost)/, r => r.abort());  // third-party logos are not part of the budget
    await p.goto(url); await p.waitForFunction(() => window.__mpT && window.__mpT.ready, null, { timeout: 20000 }).catch(() => { throw new Error("the site did not start (a data file is missing or damaged)"); }); return p;
  };
  let p = await open(false);
  chk("ready to use (fast connection)", await p.evaluate(() => window.__mpT.ready), B.readyMs, "ms");
  chk("page elements on first screen", await p.evaluate(() => document.getElementsByTagName("*").length), B.domNodes, "");
  const L = await p.evaluate(async () => {
    const t = performance.now(); SET.lang = "ar"; saveSet(); applySet();
    while (document.documentElement.dir !== "rtl" || !/^[؀-ۿ]/.test(document.querySelector("nav button, .tabs button, header button").textContent.trim())) { if (performance.now() - t > 8000) break; await new Promise(r => setTimeout(r, 25)); }
    const ms = Math.round(performance.now() - t); SET.lang = "en"; saveSet(); applySet(); return { ms, over: document.documentElement.scrollWidth > innerWidth + 1 };
  });
  chk("language switch (Arabic)", L.ms, B.langMs, "ms"); chk("no sideways scrolling at 360px", L.over ? 1 : 0, 0, L.over ? "overflow" : "");
  const R = await p.evaluate(async () => { show("trackers"); document.documentElement.style.scrollBehavior = "auto"; const t0 = performance.now(); let n = 0, last = 0;
    for (let i = 0; i < 400; i++) { window.scrollTo(0, document.body.scrollHeight); await new Promise(r => setTimeout(r, 30)); n = document.querySelectorAll("#list .row").length; if (n === last && i > 20 && i % 10 == 0 && n > 3000) break; last = n; }
    return { n, ms: Math.round(performance.now() - t0) }; });
  chk("long list: rows reached", R.n, B.listRows, "", R.n >= B.listRows); chk("long list: time to scroll through", R.ms, B.listMs, "ms");
  await p.context().close();
  p = await open(true); chk("ready to use (slow connection, 1.6 Mbit/s)", await p.evaluate(() => window.__mpT.ready), B.readySlowMs, "ms");
  chk("JavaScript errors", errs.length, B.jsErrors, errs.length ? errs[0].slice(0, 80) : "");
  await br.close(); srv.close();
  let fail = 0; console.log("MarketPulse performance budget  " + new Date().toISOString().slice(0, 10));
  for (const r of rows) { if (!r.ok) fail++; console.log((r.ok ? "PASS " : "FAIL ") + r.name + ": " + r.val + (r.unit && /^[A-Za-z]{1,2}$/.test(r.unit) ? " " + r.unit : "") + "  (limit " + r.limit + (r.unit && /^[A-Za-z]{1,2}$/.test(r.unit) ? " " + r.unit : "") + ")" + (r.unit && !/^[A-Za-z]{0,2}$/.test(r.unit) ? "  " + r.unit : "")); }
  console.log(fail ? "RESULT: FAIL (" + fail + " of " + rows.length + " checks)" : "RESULT: PASS (all " + rows.length + " checks)"); process.exit(fail ? 1 : 0);
})().catch(e => { console.log("RESULT: FAIL (script error) " + e.message); process.exit(1); });
